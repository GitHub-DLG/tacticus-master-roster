
document.addEventListener("DOMContentLoaded", function() {
    fetch("roster_data.json")
        .then(response => response.json())
        .then(data => {
            const rosterContainer = document.getElementById("roster-container");
            rosterContainer.innerHTML = ""; // Clear loading message

            data.factions.forEach(faction => {
                const factionSection = document.createElement("section");
                factionSection.classList.add("faction-section");

                const factionHeader = document.createElement("h2");
                factionHeader.classList.add("faction-header");
                factionHeader.textContent = faction.name;
                factionSection.appendChild(factionHeader);

                const characterGrid = document.createElement("div");
                characterGrid.classList.add("character-grid");

                faction.characters.forEach(character => {
                    const characterCard = document.createElement("div");
                    characterCard.classList.add("character-card");

                    const priorityClass = character.priority === "N/A" ? "NA" : character.priority;
                    const statusClass = character.status.toLowerCase();

                    characterCard.innerHTML = `
                        <h3>${character.name}</h3>
                        <p class="character-id">${character.id}</p>
                        <p class="status ${statusClass}">${character.status}</p>
                        <p class="rank-stars">Rank: ${character.rank}</p>
                        <p class="level-cap">Level: ${character.level}</p>
                        <p class="abilities">Abilities: ${character.abilities}</p>
                        <p class="priority ${priorityClass}">Priority: ${character.priority}</p>
                        <p class="description">${character.description}</p>
                    `;
                    characterGrid.appendChild(characterCard);
                });

                factionSection.appendChild(characterGrid);
                rosterContainer.appendChild(factionSection);
            });
        })
        .catch(error => {
            console.error("Error loading roster data:", error);
            document.getElementById("roster-container").innerHTML = "<p>Failed to load roster data. Please try again later.</p>";
        });
});


